-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 02 Sep 2023 pada 18.01
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `indpdb_myumkm`
--
CREATE DATABASE IF NOT EXISTS `indpdb_myumkm` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `indpdb_myumkm`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `myu_account`
--

CREATE TABLE IF NOT EXISTS `myu_account` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(50) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `authority` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`authority`)),
  `registration_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`registration_data`)),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `myu_account`:
--

--
-- Dumping data untuk tabel `myu_account`
--

INSERT INTO `myu_account` (`id`, `uuid`, `username`, `password`, `email`, `authority`, `registration_data`) VALUES
(1, '39a14955-e7fa-44f6-9b9e-7786368cd674', 'admin_master', '96cae35ce8a9b0244178bf28e4966c2ce1b8385723a96a6b838858cdd6ca0a1e', 'admin.master@mail.com', '{}', '{\"regis_date\": \"2023-05-10 22:14:51\", \"deletable\": false}');

-- --------------------------------------------------------

--
-- Struktur dari tabel `myu_app_manifest`
--

CREATE TABLE IF NOT EXISTS `myu_app_manifest` (
  `manifest_code` varchar(100) NOT NULL,
  `manifest_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`manifest_value`)),
  PRIMARY KEY (`manifest_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `myu_app_manifest`:
--

--
-- Dumping data untuk tabel `myu_app_manifest`
--

INSERT INTO `myu_app_manifest` (`manifest_code`, `manifest_value`) VALUES
('AUTHENTICATION', '{\"basic\": {\"general\": {\"username\": \"dpfir\", \"password\": \"123123\"}, \"email\": {\"username\": \"dpfir_email\", \"password\": \"123123\"}, \"page_template\": {\"username\": \"dpfir_pagetemplate\", \"password\": \"123123\"}}, \"api_key\": \"aGVsbG93b3JsZF8xMjMxMjM=\", \"google_api_2_oauth\": {\"client_id\": \"\", \"client_secret\": \"\"}, \"google_api_key\": \"\"}'),
('OWNER_CONTACT', '{\"site_name\":\"My UMKM\",\"address\":\"Jl. Angsana I  Rt. 002\\/Rw. 06  No.5 Kel. Pejaten Timur, Kec. Pasar Minggu Jakarta Selatan. 12510\",\"email\":\"cs@myumkm.com\",\"phone_number\":\"6281328660009\",\"office_number\":\"\",\"social_media\":{\"instagram\":{\"url\":\"https:\\/\\/instagram.com\\/\",\"icon\":\"ri-instagram-line\",\"img\":\"\",\"username\":\"putsutech\",\"placeholder\":\"username\"},\"whatsapp\":{\"url\":\"https:\\/\\/wa.me\\/\",\"icon\":\"ri-whatsapp-line\",\"img\":\"\",\"username\":\"6281328660009\",\"placeholder\":\"6281234567890\"},\"facebook\":{\"url\":\"https:\\/\\/facebook.com\\/\",\"icon\":\"ri-facebook-circle-line\",\"img\":\"\",\"username\":\"putsutech\",\"placeholder\":\"username\"},\"youtube\":{\"url\":\"https:\\/\\/youtu.be\\/\",\"icon\":\"ri-youtube-line\",\"img\":\"\",\"username\":\"\",\"placeholder\":\"username\"},\"linkedin\":{\"url\":\"https:\\/\\/linkedin.com\\/\",\"icon\":\"ri-linkedin-box-fill\",\"img\":\"\",\"username\":\"\",\"placeholder\":\"username\"},\"twitter\":{\"url\":\"https:\\/\\/twitter.com\\/\",\"icon\":\"ri-twitter-x-line\",\"img\":\"\",\"username\":\"\",\"placeholder\":\"username\"},\"tiktok\":{\"url\":\"https:\\/\\/tiktok.com\\/\",\"icon\":\"ri-tiktok-fill\",\"img\":\"\",\"username\":\"\",\"placeholder\":\"username\"},\"quora\":{\"url\":\"https:\\/\\/quora.com\\/\",\"icon\":\"\",\"img\":\"logo\\/third_party\\/logo-quora.svg\",\"username\":\"\",\"placeholder\":\"username\"}},\"marketplace\":{\"tokopedia\":{\"url\":\"https:\\/\\/tokopedia.com\\/\",\"icon\":\"\",\"img\":\"logo\\/third_party\\/logo-tokopedia.svg\",\"username\":\"\",\"placeholder\":\"username\"},\"shopee\":{\"url\":\"https:\\/\\/shopee.com\\/\",\"icon\":\"\",\"img\":\"logo\\/third_party\\/logo-shopee.svg\",\"username\":\"\",\"placeholder\":\"username\"},\"bukalapak\":{\"url\":\"https:\\/\\/bukalapak.com\\/\",\"icon\":\"\",\"img\":\"logo\\/third_party\\/logo-bukalapak.svg\",\"username\":\"\",\"placeholder\":\"username\"},\"blibli\":{\"url\":\"https:\\/\\/blibli.com\\/\",\"icon\":\"\",\"img\":\"logo\\/third_party\\/logo-blibli.svg\",\"username\":\"\",\"placeholder\":\"username\"},\"zalora\":{\"url\":\"https:\\/\\/zalora.com\\/\",\"icon\":\"\",\"img\":\"logo\\/third_party\\/logo-zalora.svg\",\"username\":\"\",\"placeholder\":\"username\"},\"lazada\":{\"url\":\"https:\\/\\/lazada.com\\/\",\"icon\":\"\",\"img\":\"logo\\/third_party\\/logo-lazada.svg\",\"username\":\"\",\"placeholder\":\"username\"}}}'),
('PAYMENT_METHOD', '{\"BCA\":{\"name\":\"Bank Central Asia\",\"icon\":\"\",\"img\":\"logo/third_party/logo-bca.svg\"},\"BRI\":{\"name\":\"Bank Rakyat Indonesia\",\"icon\":\"\",\"img\":\"logo/third_party/logo-bri.svg\"},\"BNI\":{\"name\":\"Bank Negara Indonesia\",\"icon\":\"\",\"img\":\"logo/third_party/logo-bni.svg\"},\"CIMB\":{\"name\":\"CIMB Niaga\",\"icon\":\"\",\"img\":\"logo/third_party/logo-cimb.svg\"},\"MANDIRI\":{\"name\":\"Bank Mandiri\",\"icon\":\"\",\"img\":\"logo/third_party/logo-mandiri.svg\"},\"PERMATA\":{\"name\":\"Bank Permata\",\"icon\":\"\",\"img\":\"logo/third_party/logo-permata.svg\"},\"BSI\":{\"name\":\"Bank Syariah Indonesia\",\"icon\":\"\",\"img\":\"logo/third_party/logo-bsi.svg\"},\"MEGA\":{\"name\":\"Bank Mega Indonesia\",\"icon\":\"\",\"img\":\"logo/third_party/logo-mega.svg\"},\"DANAMON\":{\"name\":\"Bank Danamon Indonesia\",\"icon\":\"\",\"img\":\"logo/third_party/logo-danamon.svg\"},\"MAYBANK\":{\"name\":\"Bank Maybank Indonesia\",\"icon\":\"\",\"img\":\"logo/third_party/logo-maybank.svg\"},\"SAMPOERNA\":{\"name\":\"Bank Sahabat Sampoerna\",\"icon\":\"\",\"img\":\"logo/third_party/logo-sampoerna.svg\"},\"GOPAY\":{\"name\":\"Gopay\",\"icon\":\"\",\"img\":\"logo/third_party/logo-gopay.svg\"},\"DANA\":{\"name\":\"DANA\",\"icon\":\"\",\"img\":\"logo/third_party/logo-dana.svg\"},\"SHOPEEPAY\":{\"name\":\"Shopeepay\",\"icon\":\"\",\"img\":\"logo/third_party/logo-shopeepay.svg\"},\"OVO\":{\"name\":\"OVO\",\"icon\":\"\",\"img\":\"logo/third_party/logo-ovo.svg\"}}'),
('UPLOAD_SETTING', '{\"image\":{\"compress\":\"0.5\",\"max_size\":{\"size\":\"1\",\"unit\":\"mb\"}}}');

-- --------------------------------------------------------

--
-- Struktur dari tabel `myu_blog`
--

CREATE TABLE IF NOT EXISTS `myu_blog` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `author_id` varchar(10) NOT NULL,
  `thumbnail_path` varchar(50) NOT NULL,
  `tags` varchar(100) NOT NULL,
  `status` enum('SHOW','ARCHIVE','PENDING') NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `date` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`date`)),
  `reputation` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`reputation`)),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `myu_blog`:
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `myu_catalog`
--

CREATE TABLE IF NOT EXISTS `myu_catalog` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `category_id` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `price` int(10) NOT NULL,
  `image_path` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`image_path`)),
  `status` enum('ARCHIVE','SHOW','PENDING','DELETED') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `myu_catalog`:
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `myu_catalog_category`
--

CREATE TABLE IF NOT EXISTS `myu_catalog_category` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  `image_path` varchar(50) NOT NULL,
  `type` enum('SERVICE','PRODUCT') NOT NULL,
  `slug` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `myu_catalog_category`:
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `myu_client`
--

CREATE TABLE IF NOT EXISTS `myu_client` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `wa_number` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `address` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `myu_client`:
--

--
-- Dumping data untuk tabel `myu_client`
--

INSERT INTO `myu_client` (`id`, `name`, `phone_number`, `wa_number`, `email`, `address`) VALUES
(1, 'Rifky', '08123456789', '08123456789', 'ralfian096@gmail.com', 'Karawang');

-- --------------------------------------------------------

--
-- Struktur dari tabel `myu_client_candidate`
--

CREATE TABLE IF NOT EXISTS `myu_client_candidate` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `client_id` varchar(10) NOT NULL,
  `business_name` varchar(100) NOT NULL,
  `business_logo` varchar(30) NOT NULL,
  `bussiness_address` varchar(250) NOT NULL,
  `bussiness_contact` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`bussiness_contact`)),
  `bussiness_socmed` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`bussiness_socmed`)),
  `bussiness_marketplace` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`bussiness_marketplace`)),
  `bussiness_category` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`bussiness_category`)),
  `business_legal` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`business_legal`)),
  `photos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`photos`)),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `myu_client_candidate`:
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `myu_client_review`
--

CREATE TABLE IF NOT EXISTS `myu_client_review` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `client_id` varchar(10) NOT NULL,
  `profession` varchar(100) NOT NULL,
  `rate` int(2) NOT NULL,
  `review` text NOT NULL,
  `review_date` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `update_date` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `myu_client_review`:
--

--
-- Dumping data untuk tabel `myu_client_review`
--

INSERT INTO `myu_client_review` (`id`, `client_id`, `profession`, `rate`, `review`, `review_date`, `update_date`) VALUES
(1, '1', 'UMKM', 5, 'Tampilan halaman admin sederhana dan mudah dipahami. Memudahkan saya untuk mengelola konten di dalam website.', '2023-08-02 12:15:20', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `myu_mail`
--

CREATE TABLE IF NOT EXISTS `myu_mail` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `message` varchar(1000) NOT NULL,
  `date` varchar(25) NOT NULL,
  `browser_id` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`browser_id`)),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `myu_mail`:
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `myu_payment_method`
--

CREATE TABLE IF NOT EXISTS `myu_payment_method` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `method` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `number` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `myu_payment_method`:
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `myu_portofolio`
--

CREATE TABLE IF NOT EXISTS `myu_portofolio` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `url` varchar(50) NOT NULL,
  `image_path` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELATIONSHIPS FOR TABLE `myu_portofolio`:
--

--
-- Dumping data untuk tabel `myu_portofolio`
--

INSERT INTO `myu_portofolio` (`id`, `name`, `description`, `url`, `image_path`) VALUES
(1, 'Dapur Firdaus', 'Website UMKM bernama Dapur Firdaus', 'https://dapurfirdaus.myumkm.com', '230901/MYU_1693599928106.webp'),
(2, 'Dapur Mak Ojah', 'Website UMKM bernama Dapur Mak Ojah', 'https://dapurmakojah.myumkm.com', '230901/MYU_16935999626398.webp'),
(3, 'Dapur Aneka Rasa', 'Website UMKM bernama Dapur Aneka Rasa', 'https://daras.myumkm.com', '230901/MYU_16935999927481.webp'),
(4, 'Legenda Gula Jawa', 'Website UMKM bernama Legenda Gula Jawa', 'https://gulajawa.myumkm.com', '230901/MYU_16936000250611.webp'),
(5, 'Syaputri Snack', 'Website UMKM bernama Syaputri Snack', 'https://syaputri.myumkm.com', '230901/MYU_1693600058818.webp'),
(6, 'Wasit Shop', 'Website UMKM bernama Wasit Shop', 'https://wasit.myumkm.com', '230901/MYU_16936000830739.webp'),
(7, 'PT Ranss Tujuh Puluh', 'Website Company Profile untuk PT Ranss Tujuh Puluh', 'https://ranss70.putsutech.com', '230901/MYU_16936001206162.webp'),
(8, 'Website Mockup', 'Website mockup', '#', '230901/MYU_16936001424876.webp');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
